#ifndef COMPLEX_ARG
#define COMPLEX_ARG
#include "complex.h"

double arg(Complex x) {
  return 0.0;
}
#endif