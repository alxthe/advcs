#include "complex.h"

double imag(Complex rhs){
  return rhs.i;

};