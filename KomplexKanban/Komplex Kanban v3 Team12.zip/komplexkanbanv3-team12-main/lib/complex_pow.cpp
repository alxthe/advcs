#include "complex.h"
#include <cmath>

double pow(double a, double b) { return pow(a, b); }
