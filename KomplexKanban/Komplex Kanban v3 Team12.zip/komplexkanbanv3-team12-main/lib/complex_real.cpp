#include "complex.h"

double real(Complex x) {
  return x.r;
}