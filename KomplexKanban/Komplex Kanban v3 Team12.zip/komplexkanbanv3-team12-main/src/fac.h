/* Simple test to try catch2 */
unsigned int Factorial( unsigned int number );